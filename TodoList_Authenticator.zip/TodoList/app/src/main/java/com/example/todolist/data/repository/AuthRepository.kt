package com.example.todolist.data.repository

import com.google.firebase.auth.AuthResult
import com.google.firebase.auth.FirebaseUser

interface AuthRepository {
    val currentUser: FirebaseUser?
    suspend fun login(email: String, pass: String): Result<AuthResult>
    suspend fun signUp(email: String, pass: String): Result<AuthResult>
    fun logout()
}