package com.example.todolist.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [TodoEntity::class],
    version = 1,
    exportSchema = true
)
abstract class TodoDataBase : RoomDatabase() {

    abstract val todoDao: TodoDao
}

object TodoDataBaseProvider {

    @Volatile
    private var instance: TodoDataBase? = null

    fun provide(context: Context): TodoDataBase {
        return instance ?: synchronized(this) {
            val instance = Room.databaseBuilder(
                context.applicationContext,
                TodoDataBase::class.java,
                "todo_app"
            ).build()
            this.instance = instance
            instance

        }
    }
}