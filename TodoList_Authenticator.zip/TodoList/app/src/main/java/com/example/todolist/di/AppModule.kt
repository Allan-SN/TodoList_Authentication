package com.example.todolist.di

import android.content.Context
import androidx.room.Room
import com.example.todolist.data.TodoDao
import com.example.todolist.data.TodoDataBase
import com.example.todolist.data.TodoRepository
import com.example.todolist.data.TodoRepositoryImpl
import com.example.todolist.data.repository.AuthRepository
import com.example.todolist.data.repository.AuthRepositoryImpl
import com.google.firebase.auth.FirebaseAuth
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class AppModule {

    @Binds
    @Singleton
    abstract fun bindTodoRepository(impl: TodoRepositoryImpl): TodoRepository

    @Binds
    @Singleton
    abstract fun bindAuthRepository(impl: AuthRepositoryImpl): AuthRepository

    companion object {
        @Provides
        @Singleton
        fun provideFirebaseAuth(): FirebaseAuth = FirebaseAuth.getInstance()

        @Provides
        @Singleton
        fun provideTodoDatabase(@ApplicationContext context: Context): TodoDataBase {
            return Room.databaseBuilder(
                context,
                TodoDataBase::class.java,
                "todo_db"
            ).build()
        }

        @Provides
        @Singleton
        fun provideTodoDao(db: TodoDataBase): TodoDao = db.todoDao
    }
}